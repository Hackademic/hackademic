<?php 
	//echo "Wait a few, this site is under construction";
	header("Location: inside/contact.html");
	exit;
?>
