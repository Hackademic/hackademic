<?php 
	//echo "Wait a few, this site is under construction";
	header("Location: inside/main_index.php");
	exit;
?>
