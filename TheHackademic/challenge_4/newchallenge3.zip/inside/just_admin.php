<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>JUST GO </title>
</head>

<div>
  <body background="../images/images.jpeg"><center/>
 <div/>
<div style=" margin-top:70px;color:#FFF; font-size:40px ; text-align:center">Admin Login&nbsp;&nbsp;&nbsp;<font color="#FFFFFF"><font/><br>
<font size="3" color="#FFFFFF">
</font>

<?php
	// echo "<div style=' margin-top:20px;color:#000000; font-size:24px; text-align:center'> &nbsp;&nbsp;&nbsp;<font color='#FF0000'> </font><br></div>";
	// echo "<div  align='center' style='margin:20px 0px 0px 510px;border:20px; background-color:#000000; text-align:center;width:400px; height:150px;'>";
	// echo "<div style='padding-top:10px; font-size:15px;'>";
 // 	echo "<br/>";

	// echo "<!--Form to post the contents -->";
	// echo '<form action=" " name="form1" method="post">';

	// echo ' <div style="margin-top:15px; height:30px;">Username : &nbsp;&nbsp;&nbsp;';
	// echo '   <input type="text"  name="uname" value=""/>  </div>';
  
	// echo ' <div> Password : &nbsp; &nbsp; &nbsp;';
	// echo '   <input type="password" name="passwd" value=""/></div></br>';	
	// echo "<br/><br/><br/>";
	// echo '   <div style=" margin-top:9px;margin-left:90px;"><input type="submit" name="submit" value="Submit" /></div>';

	// echo '</form>';
	// echo '</div>';
	// echo '</div>';
	// echo '<div style=" margin-top:10px;color:#FFF; font-size:23px; text-align:center">';
	// echo '<font size="3" color="#000000">';
	// echo '<center><br>';
	// echo '</center>';



?>
<br/><br/>
</script>
<div align="center">
<center>
<table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="20%" id="AutoNumber4" height="13">
<tr>
<td width="100%" height="10">
<form action="solution.php" method=post>

    <table width=259 cellpadding=3 cellspacing=0 id=1>
      
<tr>
       <td align=left class="login"><font size="2" face="Tahoma">&nbsp; &nbsp;Username:</font></td>
<td align=center>
          <input type='text' name="user" size=15 maxsize=10 value='' class="login" >
        </td>

<tr>
        <td align=left class="login"><font size="2" face="Tahoma">&nbsp; &nbsp;Password:</font></td>
<td align=center>
          <input type='password' name="pwd" size=15 maxsize=10 value='' class="login" >
        </td>

<tr>
<td align=center colspan=2>
          <br>
          <input type='submit' value='Log in' class="login">
        </td>

</table>
</form>
</p>
</td>
</tr>
</table>
</center>
</div>

</div></br></br></br><center>
</br>
</br>
<br/>
<br/>
<br/>
<font size = 7 color = white><b><b/><font/><br/><br/>
</br>
</br>
</br>
<font size='4' color= "#33FFFF">
<?php
?>
</font> 
</center>
</body>
</html>