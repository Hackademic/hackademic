<?php
define('DB_HOST', 'localhost');
define('DB_TYPE', 'mysql');
define('DB_USER', 'username');
define('DB_PASSWORD', 'password');
define('DB_NAME', 'database');
?>