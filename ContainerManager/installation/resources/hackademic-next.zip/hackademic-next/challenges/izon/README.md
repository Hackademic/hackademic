Izon Challenge For Hackademic
=============================

## Installation
To install Izon Challenge in [Hackademic CMS] (https://www.github.com/Hackademic/) just download
the challenge as a zip file and import it into Hackademic (Upload Challenge).
Afterwars, you have to edit the config.inc.php file to supply credentials for a user with access to
```sql
CREATE DATABASE, CREATE USER, DROP DATABASE, DROP USER, REVOKE, GRANT 
```

